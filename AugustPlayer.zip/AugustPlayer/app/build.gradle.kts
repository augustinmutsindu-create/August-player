plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.augustart.videoplayer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.augustart.videoplayer"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }

    // Clé de signature fixe : chaque nouvelle version s'installe par-dessus la précédente.
    signingConfigs {
        getByName("debug") {
            storeFile = file("augustart-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Moteur libVLC : le même décodage que l'application VLC (LGPL 2.1)
    implementation("org.videolan.android:libvlc-all:3.7.6")
}
