package com.augustart.videoplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

private val BG = Color.parseColor("#07070C")
private val CARD = Color.parseColor("#1B1630")
private val GOLD = Color.parseColor("#F5C451")
private val PURPLE = Color.parseColor("#7B2FF7")
private val TEXT = Color.parseColor("#F4F1FF")
private val MUTED = Color.parseColor("#A89FC4")

/** Écran principal : bibliothèque des vidéos, par catégorie, avec recherche. */
class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var all: List<Video> = emptyList()
    private val categories = HashMap<String, String>()   // uri -> catégorie
    private var shown: List<Video> = emptyList()
    private var tab = 0                                   // 0 = Tous, sinon index dans CATEGORIES
    private var query = ""

    private lateinit var tabBar: LinearLayout
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private lateinit var counter: TextView
    private lateinit var adapter: VideoAdapter

    private val tabNames = listOf("Tous") + Library.CATEGORIES

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        root.setPadding(dp(14), dp(18), dp(14), 0)

        val title = text("August Player", GOLD, 24f)
        title.typeface = Typeface.DEFAULT_BOLD
        root.addView(title, LinearLayout.LayoutParams(MATCH, WRAP))

        counter = text("", MUTED, 13f)
        root.addView(counter, spaced(0, 2, 0, 12))

        val search = EditText(this)
        search.hint = "Rechercher une vidéo"
        search.setHintTextColor(MUTED)
        search.setTextColor(TEXT)
        search.textSize = 15f
        search.setSingleLine(true)
        search.background = rounded(CARD, dp(14).toFloat())
        search.setPadding(dp(14), dp(10), dp(14), dp(10))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim().orEmpty()
                refresh()
            }
        })
        root.addView(search, spaced(0, 0, 0, 10))

        tabBar = LinearLayout(this)
        tabBar.orientation = LinearLayout.HORIZONTAL
        root.addView(tabBar, LinearLayout.LayoutParams(MATCH, WRAP))
        buildTabs()

        empty = text("", MUTED, 15f)
        empty.gravity = Gravity.CENTER
        empty.setPadding(dp(20), dp(40), dp(20), dp(20))
        root.addView(empty, LinearLayout.LayoutParams(MATCH, WRAP))

        adapter = VideoAdapter()
        list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.isVerticalScrollBarEnabled = false
        list.selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))

        setContentView(root)

        if (hasVideoPermission()) {
            loadVideos()
        } else {
            requestPermissions(arrayOf(videoPermission()), 1)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (hasVideoPermission()) {
                loadVideos()
            } else {
                empty.text = "Autorisez l'accès aux vidéos pour voir votre bibliothèque."
                counter.text = ""
            }
        }
    }

    private fun videoPermission(): String {
        return if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
    }

    private fun hasVideoPermission(): Boolean {
        return checkSelfPermission(videoPermission()) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadVideos() {
        io.execute {
            val videos = Library.scan(applicationContext)
            val cats = HashMap<String, String>()
            for (v in videos) {
                cats[v.uri] = Library.category(applicationContext, v)
            }
            handler.post {
                all = videos
                categories.clear()
                categories.putAll(cats)
                refresh()
            }
        }
    }

    private fun buildTabs() {
        tabBar.removeAllViews()
        for (i in tabNames.indices) {
            val selected = i == tab
            val tv = text(tabNames[i], if (selected) Color.BLACK else TEXT, 13f)
            tv.gravity = Gravity.CENTER
            tv.typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            tv.background = rounded(if (selected) GOLD else CARD, dp(16).toFloat())
            tv.setPadding(dp(4), dp(9), dp(4), dp(9))
            tv.setOnClickListener {
                tab = i
                buildTabs()
                refresh()
            }
            val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            tabBar.addView(tv, lp)
        }
    }

    /** Recalcule la liste visible selon l'onglet et la recherche. */
    private fun refresh() {
        val wanted = if (tab == 0) null else tabNames[tab]
        shown = all.filter { v ->
            val cat = categories[v.uri] ?: "Films"
            (wanted == null || cat == wanted) &&
                (query.isEmpty() || v.name.contains(query, ignoreCase = true))
        }
        adapter.notifyDataSetChanged()
        counter.text = if (all.isEmpty()) "" else shown.size.toString() + " vidéo(s)"
        empty.text = when {
            !hasVideoPermission() -> "Autorisez l'accès aux vidéos."
            all.isEmpty() -> "Aucune vidéo trouvée sur ce téléphone."
            shown.isEmpty() -> "Aucune vidéo dans cette catégorie."
            else -> ""
        }
        empty.visibility = if (empty.text.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun chooseCategory(video: Video) {
        val names = Library.CATEGORIES.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Catégorie de « " + video.name + " »")
            .setItems(names) { _, which ->
                val cat = names[which]
                Library.setCategory(applicationContext, video.uri, cat)
                categories[video.uri] = cat
                refresh()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun openPlayer(video: Video) {
        val intent = Intent(this, PlayerActivity::class.java)
        intent.putExtra("uri", video.uri)
        intent.putExtra("name", video.name)
        startActivity(intent)
    }

    private fun duration(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) {
            String.format("%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
        } else {
            String.format("%02d:%02d", s / 60, s % 60)
        }
    }

    // ------------------------------------------------------------------ liste

    private inner class VideoAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val video = shown[position]
            val row = LinearLayout(this@MainActivity)
            row.orientation = LinearLayout.VERTICAL
            row.background = rounded(CARD, dp(12).toFloat())
            row.setPadding(dp(14), dp(12), dp(14), dp(12))
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.setMargins(0, 0, 0, dp(8))
            row.layoutParams = lp

            val name = text(video.name, TEXT, 16f)
            name.typeface = Typeface.DEFAULT_BOLD
            name.maxLines = 2
            row.addView(name)

            val cat = categories[video.uri] ?: "Films"
            row.addView(text(cat + "  ·  " + duration(video.durationMs), MUTED, 13f))

            row.isClickable = true
            row.setOnClickListener { openPlayer(video) }
            row.setOnLongClickListener {
                chooseCategory(video)
                true
            }
            return row
        }
    }

    // ------------------------------------------------------------------ outils

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun text(t: String, color: Int, size: Float): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(color)
        tv.textSize = size
        return tv
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = radius
        return d
    }

    private fun spaced(l: Int, t: Int, r: Int, b: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(dp(l), dp(t), dp(r), dp(b))
        return lp
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }
}
