package com.augustart.videoplayer

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore

/** Une vidéo trouvée sur le téléphone. */
data class Video(val uri: String, val name: String, val durationMs: Long)

/** Lecture de la liste des vidéos, catégories et reprise de lecture. */
object Library {
    val CATEGORIES = listOf("Films", "Séries", "Animations", "Comédies")

    private val SERIES_PATTERN = Regex("S\\d{1,2}E\\d{1,3}", RegexOption.IGNORE_CASE)

    private fun prefs(context: Context) = context.getSharedPreferences("august_videos", Context.MODE_PRIVATE)

    /** Toutes les vidéos du téléphone, triées par nom. */
    fun scan(context: Context): List<Video> {
        val out = ArrayList<Video>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION
        )
        val cursor = context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projection,
            null,
            null,
            MediaStore.Video.Media.DISPLAY_NAME + " ASC"
        ) ?: return out
        cursor.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val name = c.getString(1) ?: "Vidéo"
                val duration = c.getLong(2)
                val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id).toString()
                out.add(Video(uri, name.substringBeforeLast('.'), duration))
            }
        }
        return out
    }

    /** Catégorie choisie par l'utilisateur, ou devinée à partir du nom (épisode = série). */
    fun category(context: Context, video: Video): String {
        val saved = prefs(context).getString("cat:" + video.uri, null)
        if (saved != null) return saved
        return if (SERIES_PATTERN.containsMatchIn(video.name)) "Séries" else "Films"
    }

    fun setCategory(context: Context, uri: String, category: String) {
        prefs(context).edit().putString("cat:$uri", category).apply()
    }

    fun savedPosition(context: Context, uri: String): Long {
        return prefs(context).getLong("pos:$uri", 0L)
    }

    fun savePosition(context: Context, uri: String, positionMs: Long) {
        prefs(context).edit().putLong("pos:$uri", positionMs).apply()
    }
}
