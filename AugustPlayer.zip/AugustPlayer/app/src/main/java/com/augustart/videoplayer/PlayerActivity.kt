package com.augustart.videoplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import kotlin.math.abs
import kotlin.math.floor

/**
 * Lecteur August Player, construit sur le moteur libVLC (celui de VLC) :
 * tous les formats et codecs que VLC lit, gestes, pistes audio, sous-titres, vitesse, reprise.
 */
class PlayerActivity : Activity() {

    private lateinit var libVLC: LibVLC
    private lateinit var vlc: MediaPlayer
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var controls: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var timeText: TextView
    private lateinit var playButton: TextView
    private lateinit var speedButton: TextView
    private lateinit var audio: AudioManager
    private lateinit var gestures: GestureDetector

    private val handler = Handler(Looper.getMainLooper())
    private var videoKey = ""
    private var resumeMs = 0L
    private var resumed = false
    private var controlsShown = true
    private var seeking = false
    private var volumeAccumulator = 0f
    private var speedIndex = 2

    private val speeds = floatArrayOf(0.25f, 0.5f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    private val hider = Runnable { setControlsVisible(false) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val uri = resolveUri()
        if (uri == null) {
            toast("Vidéo introuvable")
            finish()
            return
        }
        videoKey = uri.toString()
        resumeMs = Library.savedPosition(applicationContext, videoKey)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val frame = FrameLayout(this)
        frame.setBackgroundColor(Color.BLACK)

        videoLayout = VLCVideoLayout(this)
        frame.addView(videoLayout, FrameLayout.LayoutParams(MATCH, MATCH))

        // Calque transparent au-dessus de la vidéo : il reçoit les gestes
        val touch = View(this)
        gestures = GestureDetector(this, GestureListener())
        touch.setOnTouchListener { _, ev -> gestures.onTouchEvent(ev) }
        frame.addView(touch, FrameLayout.LayoutParams(MATCH, MATCH))

        frame.addView(buildControls(), FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        setContentView(frame)

        libVLC = LibVLC(this, arrayListOf("--network-caching=1500"))
        vlc = MediaPlayer(libVLC)
        vlc.attachViews(videoLayout, null, true, false)

        val media = Media(libVLC, uri)
        vlc.media = media
        media.release()
        vlc.play()

        handler.post(ticker)
        setControlsVisible(true)
    }

    /** Vidéo ouverte depuis la bibliothèque, ou depuis le gestionnaire de fichiers (« Ouvrir avec »). */
    private fun resolveUri(): Uri? {
        val data = intent?.data
        if (data != null) return data
        val text = intent?.getStringExtra("uri") ?: return null
        return Uri.parse(text)
    }

    // ------------------------------------------------------------------ barre de commandes

    private fun buildControls(): View {
        controls = LinearLayout(this)
        controls.orientation = LinearLayout.VERTICAL
        controls.setPadding(dp(14), dp(10), dp(14), dp(12))
        controls.background = GradientDrawable(
            GradientDrawable.Orientation.BOTTOM_TOP,
            intArrayOf(Color.parseColor("#E6000000"), Color.parseColor("#00000000"))
        )

        val title = TextView(this)
        title.text = intent?.getStringExtra("name") ?: "August Player"
        title.setTextColor(Color.WHITE)
        title.textSize = 15f
        title.typeface = Typeface.DEFAULT_BOLD
        title.maxLines = 1
        controls.addView(title, LinearLayout.LayoutParams(MATCH, WRAP))

        seek = SeekBar(this)
        seek.progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#F5C451"))
        seek.thumbTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#F5C451"))
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) timeText.text = format(progress.toLong()) + " / " + format(vlc.length)
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {
                seeking = true
                handler.removeCallbacks(hider)
            }

            override fun onStopTrackingTouch(bar: SeekBar?) {
                seeking = false
                vlc.time = (bar?.progress ?: 0).toLong()
                scheduleHide()
            }
        })
        controls.addView(seek, LinearLayout.LayoutParams(MATCH, WRAP))

        timeText = TextView(this)
        timeText.setTextColor(Color.parseColor("#D9D4EC"))
        timeText.textSize = 12f
        controls.addView(timeText, LinearLayout.LayoutParams(MATCH, WRAP))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(button("⏪") { vlc.time = (vlc.time - 10_000L).coerceAtLeast(0L) }, buttonLp(1f))
        playButton = button("⏸") { togglePlay() }
        row.addView(playButton, buttonLp(1f))
        row.addView(button("⏩") { vlc.time = vlc.time + 10_000L }, buttonLp(1f))
        speedButton = button("1×") { cycleSpeed() }
        row.addView(speedButton, buttonLp(1.2f))
        row.addView(button("Audio") { chooseAudio() }, buttonLp(1.4f))
        row.addView(button("Sous-titres") { chooseSubtitles() }, buttonLp(1.8f))
        controls.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))

        return controls
    }

    private fun togglePlay() {
        if (vlc.isPlaying) {
            vlc.pause()
            playButton.text = "▶"
        } else {
            vlc.play()
            playButton.text = "⏸"
        }
        scheduleHide()
    }

    private fun cycleSpeed() {
        speedIndex = (speedIndex + 1) % speeds.size
        val rate = speeds[speedIndex]
        vlc.rate = rate
        speedButton.text = rateLabel(rate)
        scheduleHide()
    }

    private fun rateLabel(rate: Float): String {
        return if (rate == floor(rate)) rate.toInt().toString() + "×" else rate.toString() + "×"
    }

    private fun chooseAudio() {
        val tracks = vlc.audioTracks ?: emptyArray()
        if (tracks.isEmpty()) {
            toast("Une seule piste audio")
            return
        }
        val names = tracks.map { it.name ?: "Piste" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Piste audio")
            .setItems(names) { _, which -> vlc.audioTrack = tracks[which].id }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun chooseSubtitles() {
        val tracks = vlc.spuTracks ?: emptyArray()
        val names = ArrayList<String>()
        for (t in tracks) names.add(t.name ?: "Sous-titres")
        names.add("Ajouter un fichier de sous-titres…")
        AlertDialog.Builder(this)
            .setTitle("Sous-titres")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == tracks.size) pickSubtitleFile() else vlc.spuTrack = tracks[which].id
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun pickSubtitleFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "*/*"
        startActivityForResult(intent, REQUEST_SUBTITLES)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SUBTITLES && resultCode == RESULT_OK) {
            val picked = data?.data ?: return
            vlc.addSlave(Media.Slave.Type.Subtitle, picked, true)
            toast("Sous-titres ajoutés")
        }
    }

    // ------------------------------------------------------------------ affichage et progression

    private fun updateProgress() {
        val length = vlc.length
        val time = vlc.time
        if (length > 0 && !seeking) {
            seek.max = length.toInt()
            seek.progress = time.toInt()
            timeText.text = format(time) + " / " + format(length)
        }
        // Reprise de lecture : une fois que la vidéo tourne
        if (!resumed && resumeMs > 0 && vlc.isPlaying && length > 0) {
            resumed = true
            if (resumeMs < length - 5000) vlc.time = resumeMs
        }
        playButton.text = if (vlc.isPlaying) "⏸" else "▶"
    }

    private fun setControlsVisible(visible: Boolean) {
        controlsShown = visible
        controls.visibility = if (visible) View.VISIBLE else View.GONE
        if (visible) scheduleHide()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hider)
        if (!seeking) handler.postDelayed(hider, 3500)
    }

    private fun format(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0L)
        return if (s >= 3600) {
            String.format("%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
        } else {
            String.format("%02d:%02d", s / 60, s % 60)
        }
    }

    // ------------------------------------------------------------------ gestes

    private inner class GestureListener : GestureDetector.SimpleOnGestureListener() {

        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            setControlsVisible(!controlsShown)
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            val left = e.x < videoLayout.width / 2f
            val target = if (left) vlc.time - 10_000L else vlc.time + 10_000L
            vlc.time = target.coerceAtLeast(0L)
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            val start = e1 ?: return false
            if (abs(distanceY) < abs(distanceX)) return false
            val height = videoLayout.height.coerceAtLeast(1).toFloat()
            // Glisser vers le haut = augmenter ; à gauche : luminosité, à droite : volume
            val fraction = distanceY / height
            if (start.x < videoLayout.width / 2f) changeBrightness(fraction) else changeVolume(fraction)
            return true
        }
    }

    private fun changeBrightness(delta: Float) {
        val params = window.attributes
        val current = if (params.screenBrightness < 0f) 0.5f else params.screenBrightness
        params.screenBrightness = (current + delta * 1.5f).coerceIn(0.02f, 1f)
        window.attributes = params
    }

    private fun changeVolume(delta: Float) {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        volumeAccumulator += delta * max * 1.5f
        val steps = volumeAccumulator.toInt()
        if (steps == 0) return
        volumeAccumulator -= steps
        val current = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (current + steps).coerceIn(0, max), 0)
    }

    // ------------------------------------------------------------------ cycle de vie

    override fun onPause() {
        super.onPause()
        if (::vlc.isInitialized && videoKey.isNotEmpty()) {
            val length = vlc.length
            val time = vlc.time
            // Près de la fin : on repartira du début la prochaine fois
            val position = if (length > 0 && length - time < 5000) 0L else time
            Library.savePosition(applicationContext, videoKey, position)
            vlc.pause()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::vlc.isInitialized) {
            vlc.stop()
            vlc.detachViews()
            vlc.release()
        }
        if (::libVLC.isInitialized) libVLC.release()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ outils

    private fun button(label: String, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 14f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.background = rounded(Color.parseColor("#2A2440"), dp(10).toFloat())
        tv.setOnClickListener {
            onClick()
            scheduleHide()
        }
        return tv
    }

    private fun buttonLp(weight: Float): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, dp(40), weight)
        lp.setMargins(dp(3), dp(8), dp(3), 0)
        return lp
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = radius
        return d
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val REQUEST_SUBTITLES = 7
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }
}
